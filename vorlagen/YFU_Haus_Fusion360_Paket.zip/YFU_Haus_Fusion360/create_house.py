from pathlib import Path
import math
import cadquery as cq
from lxml import etree as E
from fontTools.pens.basePen import BasePen
from fontTools.svgLib.path import parse_path
from shapely.geometry import Polygon,LineString,Point
from shapely.ops import unary_union
from shapely.affinity import affine_transform,scale,translate
ROOT=Path(__file__).resolve().parent.parent
OUT=Path(__file__).resolve().parent
class Flatten(BasePen):
 def __init__(self):super().__init__(None);self.loops=[];self.cur=[]
 def _moveTo(self,p):
  if self.cur:self.loops.append(self.cur)
  self.cur=[p]
 def _lineTo(self,p):self.cur.append(p)
 def _curveToOne(self,a,b,c):
  p=self.cur[-1]
  for i in range(1,25):
   t=i/24;u=1-t;self.cur.append((u**3*p[0]+3*u*u*t*a[0]+3*u*t*t*b[0]+t**3*c[0],u**3*p[1]+3*u*u*t*a[1]+3*u*t*t*b[1]+t**3*c[1]))
 def _qCurveToOne(self,a,b):
  p=self.cur[-1]
  for i in range(1,25):
   t=i/24;u=1-t;self.cur.append((u*u*p[0]+2*u*t*a[0]+t*t*b[0],u*u*p[1]+2*u*t*a[1]+t*t*b[1]))
 def _closePath(self):self.loops.append(self.cur);self.cur=[]
 def _endPath(self):
  if self.cur:self.loops.append(self.cur);self.cur=[]
def flatten(d):
 p=Flatten();parse_path(d,p)
 if p.cur:p.loops.append(p.cur)
 return p.loops
def filled(d):
 result=Polygon()
 for loop in flatten(d):
  if len(loop)>=3:result=result.symmetric_difference(Polygon(loop).buffer(0))
 return result
ns={'s':'http://www.w3.org/2000/svg'}
logo=E.parse(str(ROOT/'upload/Logo30Center.svg'))
polys=[]
for el in logo.findall('.//s:path',ns):
 p=filled(el.get('d'));polys.append(affine_transform(p,[.528955,0,0,.528862,-55.441405,-55.74202]))
front=unary_union(polys)
# Original hosting artwork: orange disc with its white line removed.
host=E.parse(str(ROOT/'upload/YFU_Icons_HostFamilies_full_rgb.svg'))
el=host.xpath('//*[@id="Drawing"]//s:path[@class="st6"]',namespaces=ns)[0]
lines=[LineString(a) for a in flatten(el.get('d'))]
back=Point(212,212.6).buffer(107.2,resolution=128).difference(unary_union(lines).buffer(3.5,cap_style=1,join_style=1))
def fit(p,size,cx,cy,mirror=False):
 a,b,c,d=p.bounds;p=translate(p,xoff=-(a+c)/2,yoff=-(b+d)/2);p=scale(p,xfact=(-1 if mirror else 1)*size/(c-a),yfact=-size/(c-a),origin=(0,0));return translate(p,xoff=cx,yoff=cy)
front=fit(front,25,0,61)
# Mirror rear geometry in global coordinates so it reads normally viewed from rear.
back=fit(back,25,0,61,True)
def cut_solid(p,z,depth):
 parts=list(p.geoms) if p.geom_type=='MultiPolygon' else [p];solids=[]
 for poly in parts:
  if poly.area<.0001:continue
  def wire(coords):return cq.Wire.makePolygon([cq.Vector(x,y,z) for x,y in list(coords)[:-1]],close=True)
  outer=wire(poly.exterior.coords);inners=[wire(i.coords) for i in poly.interiors]
  solids.append(cq.Solid.extrudeLinear(outer,inners,cq.Vector(0,0,depth)))
 return cq.Compound.makeCompound(solids)
# x horizontal, y height, z thickness. Front = z +4.
body=cq.Workplane('XY').polyline([(-40,6),(40,6),(40,72),(0,100),(-40,72)]).close().extrude(8).translate((0,0,-4))
foot=cq.Workplane('XY').box(90,6,24,centered=(True,False,True))
model=body.union(foot)
door=cq.Workplane('XY').box(18,32,12,centered=(True,False,True)).translate((0,6,0))
model=model.cut(door)
blank=model.val()
model=model.cut(cut_solid(front,3.4,.8)).cut(cut_solid(back,-4.2,.8))
shape=model.val()
assert shape.isValid() and len(shape.Solids())==1
cq.exporters.export(shape,str(OUT/'YFU_Haus_mit_Logos.step'))
cq.exporters.export(blank,str(OUT/'YFU_Haus_Grundkoerper.step'))
cq.exporters.export(shape,str(OUT/'YFU_Haus_mit_Logos.stl'),tolerance=.05,angularTolerance=.1)
# Planar sketch SVGs in a common 80 x 100 mm front elevation.
def svg(p,name):
 parts=list(p.geoms) if p.geom_type=='MultiPolygon' else [p]
 d=[]
 for poly in parts:
  for ring in [poly.exterior,*poly.interiors]:
   a=list(ring.coords);d.append('M '+' L '.join(f'{x+40:.5f},{100-y:.5f}' for x,y in a)+' Z')
 (OUT/name).write_text('<svg xmlns="http://www.w3.org/2000/svg" width="80mm" height="100mm" viewBox="0 0 80 100"><path fill="black" fill-rule="evenodd" d="'+' '.join(d)+'"/></svg>')
svg(front,'YFU_Logo_Vorderseite.svg');svg(scale(back,xfact=-1,yfact=1,origin=(0,0)),'Hosting_Rueckseite.svg')
print('Valid solid:',shape.isValid(),'volume mm3:',round(shape.Volume(),2),'solids:',len(shape.Solids()))
